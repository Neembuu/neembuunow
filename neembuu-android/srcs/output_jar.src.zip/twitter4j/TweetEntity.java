package twitter4j;

public abstract interface TweetEntity
{
  public abstract int getEnd();
  
  public abstract int getStart();
  
  public abstract String getText();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     twitter4j.TweetEntity
 * JD-Core Version:    0.7.0.1
 */
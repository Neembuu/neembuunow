package twitter4j.internal.http;

public abstract interface HttpResponseListener
{
  public abstract void httpResponseReceived(HttpResponseEvent paramHttpResponseEvent);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     twitter4j.internal.http.HttpResponseListener
 * JD-Core Version:    0.7.0.1
 */
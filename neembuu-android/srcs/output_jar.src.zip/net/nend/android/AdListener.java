package net.nend.android;

abstract interface AdListener
{
  public abstract void onFailedToReceiveAd();
  
  public abstract void onReceiveAd();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     net.nend.android.AdListener
 * JD-Core Version:    0.7.0.1
 */
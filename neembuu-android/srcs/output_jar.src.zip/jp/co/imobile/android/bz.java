package jp.co.imobile.android;

final class bz
{
  private int a;
  private cd b;
  private ca c;
  
  final bz a(int paramInt)
  {
    this.a = paramInt;
    return this;
  }
  
  final bz a(ca paramca)
  {
    this.c = paramca;
    return this;
  }
  
  final bz a(cd paramcd)
  {
    this.b = paramcd;
    return this;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.bz
 * JD-Core Version:    0.7.0.1
 */
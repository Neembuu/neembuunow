package jp.co.imobile.android;

import java.util.List;

final class bn
{
  private s a;
  private int b;
  private ai c;
  private List d;
  private String e;
  private String f;
  
  final bn a(int paramInt)
  {
    this.b = paramInt;
    return this;
  }
  
  final bn a(String paramString)
  {
    this.e = paramString;
    return this;
  }
  
  final bn a(List paramList)
  {
    this.d = paramList;
    return this;
  }
  
  final bn a(ai paramai)
  {
    this.c = paramai;
    return this;
  }
  
  final bn a(s params)
  {
    this.a = params;
    return this;
  }
  
  final bn b(String paramString)
  {
    this.f = paramString;
    return this;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.bn
 * JD-Core Version:    0.7.0.1
 */
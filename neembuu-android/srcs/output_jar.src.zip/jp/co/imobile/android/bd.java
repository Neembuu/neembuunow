package jp.co.imobile.android;

abstract interface bd
{
  public abstract bm a();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.bd
 * JD-Core Version:    0.7.0.1
 */
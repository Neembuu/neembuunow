package jp.co.imobile.android;

abstract class ae
{
  abstract boolean a();
  
  abstract boolean a(AdView paramAdView);
  
  abstract boolean b();
  
  abstract boolean b(AdView paramAdView);
  
  abstract boolean c();
  
  abstract boolean c(AdView paramAdView);
  
  abstract boolean d();
  
  public abstract String toString();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.ae
 * JD-Core Version:    0.7.0.1
 */
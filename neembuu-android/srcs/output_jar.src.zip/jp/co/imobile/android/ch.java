package jp.co.imobile.android;

final class ch
{
  private int a;
  private long b;
  private ar c;
  
  final ch a(int paramInt)
  {
    this.a = paramInt;
    return this;
  }
  
  final ch a(long paramLong)
  {
    this.b = paramLong;
    return this;
  }
  
  final ch a(ar paramar)
  {
    this.c = paramar;
    return this;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.ch
 * JD-Core Version:    0.7.0.1
 */
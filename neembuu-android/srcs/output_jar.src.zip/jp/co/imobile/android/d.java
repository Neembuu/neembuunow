package jp.co.imobile.android;

final class d
  implements Runnable
{
  d(a parama, AdRequestResult paramAdRequestResult) {}
  
  public final void run()
  {
    a.b(this.a, this.b);
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.d
 * JD-Core Version:    0.7.0.1
 */
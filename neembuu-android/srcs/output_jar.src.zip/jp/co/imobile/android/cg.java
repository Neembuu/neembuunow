package jp.co.imobile.android;

final class cg
{
  private final int a;
  private final long b;
  private final ar c;
  
  cg(ch paramch)
  {
    this.b = ch.a(paramch);
    this.a = ch.b(paramch);
    this.c = ch.c(paramch);
  }
  
  final int a()
  {
    return this.a;
  }
  
  final long b()
  {
    return this.b;
  }
  
  final ar c()
  {
    return this.c;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.cg
 * JD-Core Version:    0.7.0.1
 */
package jp.co.imobile.android;

 enum r
{
  static
  {
    r[] arrayOfr = new r[5];
    arrayOfr[0] = a;
    arrayOfr[1] = b;
    arrayOfr[2] = c;
    arrayOfr[3] = d;
    arrayOfr[4] = e;
    f = arrayOfr;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.r
 * JD-Core Version:    0.7.0.1
 */
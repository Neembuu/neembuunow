package jp.co.imobile.android;

final class c
  implements Runnable
{
  c(a parama, ap paramap) {}
  
  public final void run()
  {
    a locala = this.a;
    if (this.b.g()) {}
    for (AdRequestResult localAdRequestResult = AdRequestResult.e;; localAdRequestResult = AdRequestResult.c)
    {
      a.b(locala, localAdRequestResult);
      return;
    }
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.c
 * JD-Core Version:    0.7.0.1
 */
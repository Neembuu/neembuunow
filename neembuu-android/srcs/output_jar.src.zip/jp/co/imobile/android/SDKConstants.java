package jp.co.imobile.android;

public final class SDKConstants
{
  public static final String LOG_TAG = "i-mobile SDK";
  public static final String PUBLISHER_ID = "i-mobile_Publisher_ID";
  public static final String TESTING_ID = "i-mobile_Testing";
  public static final int TEXT_AD_HEIGHT = 50;
  public static final String VERSION = "1.4";
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.SDKConstants
 * JD-Core Version:    0.7.0.1
 */
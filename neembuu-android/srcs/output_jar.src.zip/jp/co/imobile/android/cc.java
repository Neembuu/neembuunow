package jp.co.imobile.android;

import java.util.List;

final class cc
{
  private int a;
  private List b;
  
  private cc(byte paramByte) {}
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.cc
 * JD-Core Version:    0.7.0.1
 */
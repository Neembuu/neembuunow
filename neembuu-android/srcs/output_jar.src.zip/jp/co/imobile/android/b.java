package jp.co.imobile.android;

final class b
  implements Runnable
{
  b(a parama, ap paramap) {}
  
  public final void run()
  {
    a locala = this.a;
    if (this.b.g()) {}
    for (AdRequestResult localAdRequestResult = AdRequestResult.d;; localAdRequestResult = AdRequestResult.b)
    {
      a.a(locala, localAdRequestResult);
      a.a(this.a, this.b);
      return;
    }
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.b
 * JD-Core Version:    0.7.0.1
 */
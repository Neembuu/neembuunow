package jp.co.imobile.android;

abstract class af
{
  private final s a;
  private final int b;
  private final ai c;
  private final boolean d;
  
  af(s params, int paramInt, ai paramai, boolean paramBoolean)
  {
    this.a = params;
    this.b = paramInt;
    this.c = paramai;
    this.d = paramBoolean;
  }
  
  final int a()
  {
    return this.b;
  }
  
  public void a(aq paramaq)
  {
    paramaq.a(this.a).e(this.b).a(this.c).b(this.d).b("").a(false);
  }
  
  final boolean b()
  {
    return this.d;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.af
 * JD-Core Version:    0.7.0.1
 */
package jp.co.imobile.android;

public abstract interface AdViewRequestListener
{
  public abstract void onCompleted(AdRequestResult paramAdRequestResult, AdView paramAdView);
  
  public abstract void onFailed(AdRequestResult paramAdRequestResult, AdView paramAdView);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.AdViewRequestListener
 * JD-Core Version:    0.7.0.1
 */
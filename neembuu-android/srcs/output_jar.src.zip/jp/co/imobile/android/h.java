package jp.co.imobile.android;

final class h
{
  final ap a;
  final AdRequestResult b;
  
  h(ap paramap, AdRequestResult paramAdRequestResult)
  {
    this.a = paramap;
    this.b = paramAdRequestResult;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.h
 * JD-Core Version:    0.7.0.1
 */
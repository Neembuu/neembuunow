package jp.co.imobile.android;

abstract interface ax
{
  public abstract Object baseValue();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.ax
 * JD-Core Version:    0.7.0.1
 */
package jp.co.imobile.android;

import android.graphics.drawable.Drawable;

final class aq
{
  private int a;
  private int b;
  private int c;
  private long d;
  private s e;
  private int f;
  private int g;
  private ai h;
  private bo i;
  private int j;
  private int k;
  private String l;
  private Drawable m;
  private boolean n;
  private boolean o;
  private ar p;
  private String q;
  
  final aq a(int paramInt)
  {
    this.c = paramInt;
    return this;
  }
  
  final aq a(long paramLong)
  {
    this.d = paramLong;
    return this;
  }
  
  final aq a(Drawable paramDrawable)
  {
    this.m = paramDrawable;
    return this;
  }
  
  final aq a(String paramString)
  {
    this.l = paramString;
    return this;
  }
  
  final aq a(ai paramai)
  {
    this.h = paramai;
    return this;
  }
  
  final aq a(ar paramar)
  {
    this.p = paramar;
    return this;
  }
  
  final aq a(bo parambo)
  {
    this.i = parambo;
    return this;
  }
  
  final aq a(s params)
  {
    this.e = params;
    return this;
  }
  
  final aq a(boolean paramBoolean)
  {
    this.n = paramBoolean;
    return this;
  }
  
  final aq b(int paramInt)
  {
    this.a = paramInt;
    return this;
  }
  
  final aq b(String paramString)
  {
    this.q = paramString;
    return this;
  }
  
  final aq b(boolean paramBoolean)
  {
    this.o = paramBoolean;
    return this;
  }
  
  final aq c(int paramInt)
  {
    this.b = paramInt;
    return this;
  }
  
  final aq d(int paramInt)
  {
    this.f = paramInt;
    return this;
  }
  
  final aq e(int paramInt)
  {
    this.g = paramInt;
    return this;
  }
  
  final aq f(int paramInt)
  {
    this.j = paramInt;
    return this;
  }
  
  final aq g(int paramInt)
  {
    this.k = paramInt;
    return this;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.aq
 * JD-Core Version:    0.7.0.1
 */
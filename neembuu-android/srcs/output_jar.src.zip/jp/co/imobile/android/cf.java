package jp.co.imobile.android;

import java.util.List;

final class cf
{
  private String a;
  private List b;
  
  final cf a(String paramString)
  {
    this.a = paramString;
    return this;
  }
  
  final cf a(List paramList)
  {
    this.b = paramList;
    return this;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.cf
 * JD-Core Version:    0.7.0.1
 */
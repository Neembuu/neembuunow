package jp.co.imobile.android;

import android.graphics.drawable.Drawable;

final class ap
{
  public static final ap a = new ap(new aq());
  private final int b;
  private final int c;
  private final bo d;
  private final int e;
  private final int f;
  private final String g;
  private Drawable h;
  private final int i;
  private final long j;
  private final s k;
  private final int l;
  private final int m;
  private final ai n;
  private final boolean o;
  private final boolean p;
  private final ar q;
  private final String r;
  
  ap(aq paramaq)
  {
    this.i = aq.a(paramaq);
    this.j = aq.b(paramaq);
    this.b = aq.c(paramaq);
    this.c = aq.d(paramaq);
    this.g = aq.e(paramaq);
    this.k = aq.f(paramaq);
    this.l = aq.g(paramaq);
    this.m = aq.h(paramaq);
    this.d = aq.i(paramaq);
    this.e = aq.j(paramaq);
    this.f = aq.k(paramaq);
    this.h = aq.l(paramaq);
    this.n = aq.m(paramaq);
    this.o = aq.n(paramaq);
    this.p = aq.o(paramaq);
    this.q = aq.p(paramaq);
    this.r = aq.q(paramaq);
  }
  
  public final s a()
  {
    return this.k;
  }
  
  public final int b()
  {
    return this.l;
  }
  
  public final int c()
  {
    return this.m;
  }
  
  public final Drawable d()
  {
    return this.h;
  }
  
  public final boolean e()
  {
    if (this.j > 0L) {}
    for (boolean bool = true;; bool = false) {
      return bool;
    }
  }
  
  public final ai f()
  {
    return this.n;
  }
  
  public final boolean g()
  {
    return this.p;
  }
  
  public final boolean h()
  {
    return this.o;
  }
  
  final ar i()
  {
    return this.q;
  }
  
  final String j()
  {
    return this.r;
  }
  
  public final String toString()
  {
    return "pid:" + this.b + ",mid:" + this.c + ",asid:" + this.i + ",advertisementId:" + this.m + ",adType:" + this.k + ",categoryId:" + this.l + ",clickAction:" + this.n + ",duration:" + this.j + ",imageType:" + this.d + ",width:" + this.e + ",height:" + this.f + ",altText:" + this.g + ",notFoundAd:" + this.o + ",houseAd:" + this.p + ",animationType:" + this.q + ",houseAdLandingURL:" + this.r;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.ap
 * JD-Core Version:    0.7.0.1
 */
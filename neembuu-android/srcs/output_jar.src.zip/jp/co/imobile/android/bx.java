package jp.co.imobile.android;

final class bx
{
  private String a;
  private bt b;
  private ca c;
  
  private bx(byte paramByte) {}
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.bx
 * JD-Core Version:    0.7.0.1
 */
package jp.co.imobile.android;

abstract interface bp
{
  public abstract String getLogContents();
  
  public abstract String getLogTag();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.bp
 * JD-Core Version:    0.7.0.1
 */
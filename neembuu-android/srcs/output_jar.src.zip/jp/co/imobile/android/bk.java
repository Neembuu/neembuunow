package jp.co.imobile.android;

import java.util.List;

final class bk
{
  private s a;
  private int b;
  private int c;
  private ai d;
  private List e;
  private boolean f = false;
  
  public final bk a(int paramInt)
  {
    this.b = paramInt;
    return this;
  }
  
  public final bk a(List paramList)
  {
    this.e = paramList;
    return this;
  }
  
  public final bk a(ai paramai)
  {
    this.d = paramai;
    return this;
  }
  
  public final bk a(s params)
  {
    this.a = params;
    return this;
  }
  
  public final bk a(boolean paramBoolean)
  {
    this.f = paramBoolean;
    return this;
  }
  
  public final bk b(int paramInt)
  {
    this.c = paramInt;
    return this;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.bk
 * JD-Core Version:    0.7.0.1
 */
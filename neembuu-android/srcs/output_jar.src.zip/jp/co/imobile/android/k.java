package jp.co.imobile.android;

import java.util.concurrent.Callable;

final class k
  implements Callable
{
  private k(a parama, byte paramByte) {}
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.k
 * JD-Core Version:    0.7.0.1
 */
package jp.co.imobile.android;

abstract interface ag
{
  public abstract af a();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.ag
 * JD-Core Version:    0.7.0.1
 */
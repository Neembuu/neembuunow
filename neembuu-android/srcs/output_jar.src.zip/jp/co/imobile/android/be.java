package jp.co.imobile.android;

import java.util.List;

final class be
{
  private int a;
  private int b;
  private long c;
  private cg d;
  private List e;
  private int f;
  private boolean g;
  private List h;
  
  private be(byte paramByte) {}
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.be
 * JD-Core Version:    0.7.0.1
 */
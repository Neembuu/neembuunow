package jp.co.imobile.android;

abstract interface q
{
  public abstract void a(AdRequestResult paramAdRequestResult);
  
  public abstract boolean a();
  
  public abstract void b(AdRequestResult paramAdRequestResult);
  
  public abstract boolean b();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.imobile.android.q
 * JD-Core Version:    0.7.0.1
 */
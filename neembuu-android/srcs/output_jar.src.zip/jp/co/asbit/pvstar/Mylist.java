package jp.co.asbit.pvstar;

public class Mylist
{
  private String description;
  private long id;
  private String name;
  private int permission;
  private String thumbnailUrl;
  private int videoCount;
  
  public String getDescription()
  {
    return this.description;
  }
  
  public long getId()
  {
    return this.id;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public int getPermission()
  {
    return this.permission;
  }
  
  public String getThumbnailUrl()
  {
    return this.thumbnailUrl;
  }
  
  public int getVideoCount()
  {
    return this.videoCount;
  }
  
  public void setDescription(String paramString)
  {
    this.description = paramString;
  }
  
  public void setId(long paramLong)
  {
    this.id = paramLong;
  }
  
  public void setName(String paramString)
  {
    this.name = paramString;
  }
  
  public void setPermission(int paramInt)
  {
    this.permission = paramInt;
  }
  
  public void setThumbnailUrl(String paramString)
  {
    this.thumbnailUrl = paramString;
  }
  
  public void setVideoCount(int paramInt)
  {
    this.videoCount = paramInt;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.asbit.pvstar.Mylist
 * JD-Core Version:    0.7.0.1
 */
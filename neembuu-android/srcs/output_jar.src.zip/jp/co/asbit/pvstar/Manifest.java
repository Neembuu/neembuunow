package jp.co.asbit.pvstar;

public final class Manifest
{
  public static final class permission
  {
    public static final String CLARION_SERVICE = "com.clarion.android.appmgr.service.ClarionService.permission.CLARION_SERVICE";
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.asbit.pvstar.Manifest
 * JD-Core Version:    0.7.0.1
 */
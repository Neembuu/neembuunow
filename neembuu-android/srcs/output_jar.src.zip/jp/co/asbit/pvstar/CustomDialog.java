package jp.co.asbit.pvstar;

import android.app.Dialog;
import android.content.Context;

public class CustomDialog
  extends Dialog
{
  public CustomDialog(Context paramContext)
  {
    super(paramContext, 2131361798);
    setCancelable(true);
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.asbit.pvstar.CustomDialog
 * JD-Core Version:    0.7.0.1
 */
package jp.co.asbit.pvstar;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.asbit.pvstar.BuildConfig
 * JD-Core Version:    0.7.0.1
 */
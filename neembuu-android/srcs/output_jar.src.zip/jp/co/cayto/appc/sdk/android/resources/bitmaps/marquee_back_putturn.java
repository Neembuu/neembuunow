package jp.co.cayto.appc.sdk.android.resources.bitmaps;

public class marquee_back_putturn
{
  public String base64 = "iVBORw0KGgoAAAANSUhEUgAAAAYAAAAGAQMAAADaAn0LAAAABlBMVEUAAACJiYk1poFGAAAADUlEQVR42mNoYGaAQQAF5gCQc8Zc5AAAAABJRU5ErkJggg==";
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.cayto.appc.sdk.android.resources.bitmaps.marquee_back_putturn
 * JD-Core Version:    0.7.0.1
 */
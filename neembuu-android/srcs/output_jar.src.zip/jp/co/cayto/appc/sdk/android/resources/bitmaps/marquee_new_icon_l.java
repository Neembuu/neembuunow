package jp.co.cayto.appc.sdk.android.resources.bitmaps;

public class marquee_new_icon_l
{
  public String base64 = "iVBORw0KGgoAAAANSUhEUgAAAEwAAAA8CAYAAADMtVzqAAACuklEQVR42u2aS09TQRTH+1HcaISENtaGRxBBYxRW6Ep3rly5xw1EwBhWfhYTE1+NRoOfwMQ19LYgbaDFxFLE9vY4Z9pb72vmPnrRpv3/k7Po7ZlzZn6duXPv6aRSEARBEARBEAQNuUo3pivCCOawCoAlCKwMQB4r+82qSheWCUAeM7tsJKcUgEQzAAMwAAMwAAMwWChgxnSGjKl0ZCvOXlEmKC5MCZ+JWHH94gf59vKKNtqYc7lw/RNMfIEVspfJPD2lOGp8+SwCp32B7d9bon5lxecBBKkzyLRso1P1+ToV5ycD+8dMmI0X2NUxah3XYg3o5GPe80v0gN1d7BuYFT88sIxso9PR5moHWED/mAmziQSs3W5rr9ffvabd8QsyhpEbp9LNmdEGxqq92KL95Tsywd7SAjW2P/0Fd3ZGrVpVtv9d2OlACwCm+hGSWZIDAMxKYG0Oqg65E+g6tLc4H+mmP/LA+LsoWzqAAVgCS1Kx2448MNVN3/3cA2ABcrcHMGuGmab/9WYTM0ylg4cP5PcOE896Vh4Awy45GMDsG0ghc1HYJarn32pBHK49kVUKfmvRbURmoxHv5fs8gJVuzUpfrWXHemUbLslwlYH7Yhm/stlVz7+RsJrlAy2wX9++0smH945XPAlydcURn8EWr2UHA1jrx7H015rw+fnqJRkznecz7oPd+J6nmiFBRQO/z8bkhCeHfz1sQB4r/kf5yH0PDFVxlQVEsV7VBbenNmBpz1RWrflECogi13kWKGMB43XK69W+fi1jWN/vL8tyrvS9nqPK40d09GzN4+te86Xbc1Td2vCNG8pEDs7FOX0H0W98xzjXe6XrUDV999p1WBeWvVav8g3rF9pcuROPr+g7/jXC32wABmDDCAwH6qIcqMORzYhHNnEoGKeo/x0wCIIgCIIgCIKGRH8A/6Uth591SGkAAAAASUVORK5CYII=";
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.cayto.appc.sdk.android.resources.bitmaps.marquee_new_icon_l
 * JD-Core Version:    0.7.0.1
 */
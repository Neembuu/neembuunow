package jp.co.cayto.appc.sdk.android.resources.bitmaps;

public class move_icon_bg_shadow
{
  public String base64 = "iVBORw0KGgoAAAANSUhEUgAAAAQAAAAcCAYAAABGdB6IAAAA6ElEQVR42lXFKVcCURgG4DcYCMjMdTaZBWZ39g3PCHJsRhqRaCQSrUYj0UikEf1x4w3znXMNz3lwP5N/ZxwNSWI3SebGITPlyph6pfGgaBem6Bcaqmr8KBwNTZ+fNd080zAM61uEx7nzJYJpLT9NkxuHZXsn2/FONJxFcHQW/pHG0o0+RHC9+OD6TwcaXpDu/SDZ0wijbBeE2Y5GGBfvEUcjTqo3EZK07kVI87ZOM24cWbFKRMjLZz+vuHEUdW+XVW/TKOsXXYS6WbOqXTMadbeZNu1mSqPptpO2e53Q6Fbbu5ajMQzDP3+io13NE0V52wAAAABJRU5ErkJggg==";
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.cayto.appc.sdk.android.resources.bitmaps.move_icon_bg_shadow
 * JD-Core Version:    0.7.0.1
 */
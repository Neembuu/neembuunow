package jp.co.cayto.appc.sdk.android.common;

class Global
{
  static Object lock = new Object();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.cayto.appc.sdk.android.common.Global
 * JD-Core Version:    0.7.0.1
 */
package jp.co.cayto.appc.sdk.android.resources.bitmaps;

public class hot_non
{
  public String base64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR42mP4//8/AAX+Av4zEpUUAAAAAElFTkSuQmCC";
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.co.cayto.appc.sdk.android.resources.bitmaps.hot_non
 * JD-Core Version:    0.7.0.1
 */
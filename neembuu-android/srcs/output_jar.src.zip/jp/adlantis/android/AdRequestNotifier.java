package jp.adlantis.android;

public abstract interface AdRequestNotifier
{
  public abstract void addRequestListener(AdRequestListener paramAdRequestListener);
  
  public abstract void removeRequestListener(AdRequestListener paramAdRequestListener);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.adlantis.android.AdRequestNotifier
 * JD-Core Version:    0.7.0.1
 */
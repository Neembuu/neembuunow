package jp.adlantis.android;

public class ViewSettings
{
  protected static int _defaultBackgroundColor = -939524096;
  
  static int defaultBackgroundColor()
  {
    return _defaultBackgroundColor;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.adlantis.android.ViewSettings
 * JD-Core Version:    0.7.0.1
 */
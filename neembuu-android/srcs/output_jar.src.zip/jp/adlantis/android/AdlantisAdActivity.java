package jp.adlantis.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class AdlantisAdActivity
  extends Activity
{
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    View localView = new View(this);
    localView.setBackgroundColor(-12626585);
    setContentView(localView);
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.adlantis.android.AdlantisAdActivity
 * JD-Core Version:    0.7.0.1
 */
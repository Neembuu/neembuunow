package jp.adlantis.android;

public class SDKVersion
{
  public static final String BUILDDATE = "2013-06-04 11:50:12";
  public static final String BUILDNUMBER = "1716";
  public static final String GIT_SHA = "6eb3350";
  public static final String VCS_VERSION = "v1.4.0-2-g6eb3350";
  public static final String VERSION = "1.4.0";
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.adlantis.android.SDKVersion
 * JD-Core Version:    0.7.0.1
 */
package jp.tjkapp.adfurikunsdk;

public abstract interface OnAdfurikunWallAdFinishListener
{
  public abstract void onAdfurikunWallAdClose();
  
  public abstract void onAdfurikunWallAdError(int paramInt);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     jp.tjkapp.adfurikunsdk.OnAdfurikunWallAdFinishListener
 * JD-Core Version:    0.7.0.1
 */
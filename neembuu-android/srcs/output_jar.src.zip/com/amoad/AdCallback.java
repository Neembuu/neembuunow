package com.amoad;

public abstract interface AdCallback
{
  public abstract void didFailToReceiveAdWithError();
  
  public abstract void didReceiveAd();
  
  public abstract void didReceiveEmptyAd();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.amoad.AdCallback
 * JD-Core Version:    0.7.0.1
 */
package com.google.ads;

import android.net.Uri;

public class as
{
  public static final Uri a = Uri.parse("content://com.google.plus.platform/token");
  public static final String[] b;
  
  static
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = "drt";
    b = arrayOfString;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.as
 * JD-Core Version:    0.7.0.1
 */
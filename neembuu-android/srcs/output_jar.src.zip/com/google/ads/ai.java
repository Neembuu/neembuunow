package com.google.ads;

import android.content.Context;

public abstract interface ai
{
  public abstract String a(Context paramContext);
  
  public abstract String a(Context paramContext, String paramString);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.ai
 * JD-Core Version:    0.7.0.1
 */
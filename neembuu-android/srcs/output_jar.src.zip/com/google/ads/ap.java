package com.google.ads;

public class ap
  extends IllegalArgumentException
{
  public ap() {}
  
  public ap(String paramString)
  {
    super(paramString);
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.ap
 * JD-Core Version:    0.7.0.1
 */
package com.google.ads;

import android.webkit.WebView;
import com.google.ads.internal.d;
import java.util.HashMap;

public abstract interface o
{
  public abstract void a(d paramd, HashMap<String, String> paramHashMap, WebView paramWebView);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.o
 * JD-Core Version:    0.7.0.1
 */
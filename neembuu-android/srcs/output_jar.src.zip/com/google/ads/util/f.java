package com.google.ads.util;

public abstract interface f<T>
{
  public abstract T b();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.util.f
 * JD-Core Version:    0.7.0.1
 */
package com.google.ads;

public abstract interface SwipeableAdListener
{
  public abstract void onAdActivated(Ad paramAd);
  
  public abstract void onAdDeactivated(Ad paramAd);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.SwipeableAdListener
 * JD-Core Version:    0.7.0.1
 */
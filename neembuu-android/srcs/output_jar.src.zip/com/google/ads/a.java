package com.google.ads;

import java.util.HashMap;
import java.util.List;

public class a
{
  private final String a;
  private final String b;
  private final List<String> c;
  private final List<String> d;
  private final HashMap<String, String> e;
  
  public a(String paramString1, String paramString2, List<String> paramList1, List<String> paramList2, HashMap<String, String> paramHashMap)
  {
    com.google.ads.util.a.a(paramString2);
    if (paramString1 != null) {
      com.google.ads.util.a.a(paramString1);
    }
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramList1;
    this.e = paramHashMap;
    this.d = paramList2;
  }
  
  public String a()
  {
    return this.a;
  }
  
  public String b()
  {
    return this.b;
  }
  
  public List<String> c()
  {
    return this.c;
  }
  
  public List<String> d()
  {
    return this.d;
  }
  
  public HashMap<String, String> e()
  {
    return this.e;
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.a
 * JD-Core Version:    0.7.0.1
 */
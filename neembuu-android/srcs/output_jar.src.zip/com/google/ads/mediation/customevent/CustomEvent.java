package com.google.ads.mediation.customevent;

public abstract interface CustomEvent
{
  public abstract void destroy();
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.mediation.customevent.CustomEvent
 * JD-Core Version:    0.7.0.1
 */
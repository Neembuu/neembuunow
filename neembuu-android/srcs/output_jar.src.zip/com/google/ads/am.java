package com.google.ads;

public class am
  extends Exception
{
  public am() {}
  
  public am(String paramString)
  {
    super(paramString);
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.am
 * JD-Core Version:    0.7.0.1
 */
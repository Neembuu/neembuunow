package com.google.ads;

public final class aq
{
  private static final char[] a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
  private static final char[] b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".toCharArray();
  private static final byte[] c;
  private static final byte[] d;
  
  static
  {
    byte[] arrayOfByte1 = new byte[''];
    arrayOfByte1[0] = -9;
    arrayOfByte1[1] = -9;
    arrayOfByte1[2] = -9;
    arrayOfByte1[3] = -9;
    arrayOfByte1[4] = -9;
    arrayOfByte1[5] = -9;
    arrayOfByte1[6] = -9;
    arrayOfByte1[7] = -9;
    arrayOfByte1[8] = -9;
    arrayOfByte1[9] = -5;
    arrayOfByte1[10] = -5;
    arrayOfByte1[11] = -9;
    arrayOfByte1[12] = -9;
    arrayOfByte1[13] = -5;
    arrayOfByte1[14] = -9;
    arrayOfByte1[15] = -9;
    arrayOfByte1[16] = -9;
    arrayOfByte1[17] = -9;
    arrayOfByte1[18] = -9;
    arrayOfByte1[19] = -9;
    arrayOfByte1[20] = -9;
    arrayOfByte1[21] = -9;
    arrayOfByte1[22] = -9;
    arrayOfByte1[23] = -9;
    arrayOfByte1[24] = -9;
    arrayOfByte1[25] = -9;
    arrayOfByte1[26] = -9;
    arrayOfByte1[27] = -9;
    arrayOfByte1[28] = -9;
    arrayOfByte1[29] = -9;
    arrayOfByte1[30] = -9;
    arrayOfByte1[31] = -9;
    arrayOfByte1[32] = -5;
    arrayOfByte1[33] = -9;
    arrayOfByte1[34] = -9;
    arrayOfByte1[35] = -9;
    arrayOfByte1[36] = -9;
    arrayOfByte1[37] = -9;
    arrayOfByte1[38] = -9;
    arrayOfByte1[39] = -9;
    arrayOfByte1[40] = -9;
    arrayOfByte1[41] = -9;
    arrayOfByte1[42] = -9;
    arrayOfByte1[43] = 62;
    arrayOfByte1[44] = -9;
    arrayOfByte1[45] = -9;
    arrayOfByte1[46] = -9;
    arrayOfByte1[47] = 63;
    arrayOfByte1[48] = 52;
    arrayOfByte1[49] = 53;
    arrayOfByte1[50] = 54;
    arrayOfByte1[51] = 55;
    arrayOfByte1[52] = 56;
    arrayOfByte1[53] = 57;
    arrayOfByte1[54] = 58;
    arrayOfByte1[55] = 59;
    arrayOfByte1[56] = 60;
    arrayOfByte1[57] = 61;
    arrayOfByte1[58] = -9;
    arrayOfByte1[59] = -9;
    arrayOfByte1[60] = -9;
    arrayOfByte1[61] = -1;
    arrayOfByte1[62] = -9;
    arrayOfByte1[63] = -9;
    arrayOfByte1[64] = -9;
    arrayOfByte1[65] = 0;
    arrayOfByte1[66] = 1;
    arrayOfByte1[67] = 2;
    arrayOfByte1[68] = 3;
    arrayOfByte1[69] = 4;
    arrayOfByte1[70] = 5;
    arrayOfByte1[71] = 6;
    arrayOfByte1[72] = 7;
    arrayOfByte1[73] = 8;
    arrayOfByte1[74] = 9;
    arrayOfByte1[75] = 10;
    arrayOfByte1[76] = 11;
    arrayOfByte1[77] = 12;
    arrayOfByte1[78] = 13;
    arrayOfByte1[79] = 14;
    arrayOfByte1[80] = 15;
    arrayOfByte1[81] = 16;
    arrayOfByte1[82] = 17;
    arrayOfByte1[83] = 18;
    arrayOfByte1[84] = 19;
    arrayOfByte1[85] = 20;
    arrayOfByte1[86] = 21;
    arrayOfByte1[87] = 22;
    arrayOfByte1[88] = 23;
    arrayOfByte1[89] = 24;
    arrayOfByte1[90] = 25;
    arrayOfByte1[91] = -9;
    arrayOfByte1[92] = -9;
    arrayOfByte1[93] = -9;
    arrayOfByte1[94] = -9;
    arrayOfByte1[95] = -9;
    arrayOfByte1[96] = -9;
    arrayOfByte1[97] = 26;
    arrayOfByte1[98] = 27;
    arrayOfByte1[99] = 28;
    arrayOfByte1[100] = 29;
    arrayOfByte1[101] = 30;
    arrayOfByte1[102] = 31;
    arrayOfByte1[103] = 32;
    arrayOfByte1[104] = 33;
    arrayOfByte1[105] = 34;
    arrayOfByte1[106] = 35;
    arrayOfByte1[107] = 36;
    arrayOfByte1[108] = 37;
    arrayOfByte1[109] = 38;
    arrayOfByte1[110] = 39;
    arrayOfByte1[111] = 40;
    arrayOfByte1[112] = 41;
    arrayOfByte1[113] = 42;
    arrayOfByte1[114] = 43;
    arrayOfByte1[115] = 44;
    arrayOfByte1[116] = 45;
    arrayOfByte1[117] = 46;
    arrayOfByte1[118] = 47;
    arrayOfByte1[119] = 48;
    arrayOfByte1[120] = 49;
    arrayOfByte1[121] = 50;
    arrayOfByte1[122] = 51;
    arrayOfByte1[123] = -9;
    arrayOfByte1[124] = -9;
    arrayOfByte1[125] = -9;
    arrayOfByte1[126] = -9;
    arrayOfByte1[127] = -9;
    c = arrayOfByte1;
    byte[] arrayOfByte2 = new byte[''];
    arrayOfByte2[0] = -9;
    arrayOfByte2[1] = -9;
    arrayOfByte2[2] = -9;
    arrayOfByte2[3] = -9;
    arrayOfByte2[4] = -9;
    arrayOfByte2[5] = -9;
    arrayOfByte2[6] = -9;
    arrayOfByte2[7] = -9;
    arrayOfByte2[8] = -9;
    arrayOfByte2[9] = -5;
    arrayOfByte2[10] = -5;
    arrayOfByte2[11] = -9;
    arrayOfByte2[12] = -9;
    arrayOfByte2[13] = -5;
    arrayOfByte2[14] = -9;
    arrayOfByte2[15] = -9;
    arrayOfByte2[16] = -9;
    arrayOfByte2[17] = -9;
    arrayOfByte2[18] = -9;
    arrayOfByte2[19] = -9;
    arrayOfByte2[20] = -9;
    arrayOfByte2[21] = -9;
    arrayOfByte2[22] = -9;
    arrayOfByte2[23] = -9;
    arrayOfByte2[24] = -9;
    arrayOfByte2[25] = -9;
    arrayOfByte2[26] = -9;
    arrayOfByte2[27] = -9;
    arrayOfByte2[28] = -9;
    arrayOfByte2[29] = -9;
    arrayOfByte2[30] = -9;
    arrayOfByte2[31] = -9;
    arrayOfByte2[32] = -5;
    arrayOfByte2[33] = -9;
    arrayOfByte2[34] = -9;
    arrayOfByte2[35] = -9;
    arrayOfByte2[36] = -9;
    arrayOfByte2[37] = -9;
    arrayOfByte2[38] = -9;
    arrayOfByte2[39] = -9;
    arrayOfByte2[40] = -9;
    arrayOfByte2[41] = -9;
    arrayOfByte2[42] = -9;
    arrayOfByte2[43] = -9;
    arrayOfByte2[44] = -9;
    arrayOfByte2[45] = 62;
    arrayOfByte2[46] = -9;
    arrayOfByte2[47] = -9;
    arrayOfByte2[48] = 52;
    arrayOfByte2[49] = 53;
    arrayOfByte2[50] = 54;
    arrayOfByte2[51] = 55;
    arrayOfByte2[52] = 56;
    arrayOfByte2[53] = 57;
    arrayOfByte2[54] = 58;
    arrayOfByte2[55] = 59;
    arrayOfByte2[56] = 60;
    arrayOfByte2[57] = 61;
    arrayOfByte2[58] = -9;
    arrayOfByte2[59] = -9;
    arrayOfByte2[60] = -9;
    arrayOfByte2[61] = -1;
    arrayOfByte2[62] = -9;
    arrayOfByte2[63] = -9;
    arrayOfByte2[64] = -9;
    arrayOfByte2[65] = 0;
    arrayOfByte2[66] = 1;
    arrayOfByte2[67] = 2;
    arrayOfByte2[68] = 3;
    arrayOfByte2[69] = 4;
    arrayOfByte2[70] = 5;
    arrayOfByte2[71] = 6;
    arrayOfByte2[72] = 7;
    arrayOfByte2[73] = 8;
    arrayOfByte2[74] = 9;
    arrayOfByte2[75] = 10;
    arrayOfByte2[76] = 11;
    arrayOfByte2[77] = 12;
    arrayOfByte2[78] = 13;
    arrayOfByte2[79] = 14;
    arrayOfByte2[80] = 15;
    arrayOfByte2[81] = 16;
    arrayOfByte2[82] = 17;
    arrayOfByte2[83] = 18;
    arrayOfByte2[84] = 19;
    arrayOfByte2[85] = 20;
    arrayOfByte2[86] = 21;
    arrayOfByte2[87] = 22;
    arrayOfByte2[88] = 23;
    arrayOfByte2[89] = 24;
    arrayOfByte2[90] = 25;
    arrayOfByte2[91] = -9;
    arrayOfByte2[92] = -9;
    arrayOfByte2[93] = -9;
    arrayOfByte2[94] = -9;
    arrayOfByte2[95] = 63;
    arrayOfByte2[96] = -9;
    arrayOfByte2[97] = 26;
    arrayOfByte2[98] = 27;
    arrayOfByte2[99] = 28;
    arrayOfByte2[100] = 29;
    arrayOfByte2[101] = 30;
    arrayOfByte2[102] = 31;
    arrayOfByte2[103] = 32;
    arrayOfByte2[104] = 33;
    arrayOfByte2[105] = 34;
    arrayOfByte2[106] = 35;
    arrayOfByte2[107] = 36;
    arrayOfByte2[108] = 37;
    arrayOfByte2[109] = 38;
    arrayOfByte2[110] = 39;
    arrayOfByte2[111] = 40;
    arrayOfByte2[112] = 41;
    arrayOfByte2[113] = 42;
    arrayOfByte2[114] = 43;
    arrayOfByte2[115] = 44;
    arrayOfByte2[116] = 45;
    arrayOfByte2[117] = 46;
    arrayOfByte2[118] = 47;
    arrayOfByte2[119] = 48;
    arrayOfByte2[120] = 49;
    arrayOfByte2[121] = 50;
    arrayOfByte2[122] = 51;
    arrayOfByte2[123] = -9;
    arrayOfByte2[124] = -9;
    arrayOfByte2[125] = -9;
    arrayOfByte2[126] = -9;
    arrayOfByte2[127] = -9;
    d = arrayOfByte2;
  }
  
  private static int a(char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte1, int paramInt2, byte[] paramArrayOfByte2)
  {
    int j;
    if (paramArrayOfChar[(paramInt1 + 2)] == '=')
    {
      paramArrayOfByte1[paramInt2] = ((byte)((paramArrayOfByte2[paramArrayOfChar[paramInt1]] << 24 >>> 6 | paramArrayOfByte2[paramArrayOfChar[(paramInt1 + 1)]] << 24 >>> 12) >>> 16));
      j = 1;
    }
    for (;;)
    {
      return j;
      if (paramArrayOfChar[(paramInt1 + 3)] == '=')
      {
        int k = paramArrayOfByte2[paramArrayOfChar[paramInt1]] << 24 >>> 6 | paramArrayOfByte2[paramArrayOfChar[(paramInt1 + 1)]] << 24 >>> 12 | paramArrayOfByte2[paramArrayOfChar[(paramInt1 + 2)]] << 24 >>> 18;
        paramArrayOfByte1[paramInt2] = ((byte)(k >>> 16));
        paramArrayOfByte1[(paramInt2 + 1)] = ((byte)(k >>> 8));
        j = 2;
      }
      else
      {
        int i = paramArrayOfByte2[paramArrayOfChar[paramInt1]] << 24 >>> 6 | paramArrayOfByte2[paramArrayOfChar[(paramInt1 + 1)]] << 24 >>> 12 | paramArrayOfByte2[paramArrayOfChar[(paramInt1 + 2)]] << 24 >>> 18 | paramArrayOfByte2[paramArrayOfChar[(paramInt1 + 3)]] << 24 >>> 24;
        paramArrayOfByte1[paramInt2] = ((byte)(i >> 16));
        paramArrayOfByte1[(paramInt2 + 1)] = ((byte)(i >> 8));
        paramArrayOfByte1[(paramInt2 + 2)] = ((byte)i);
        j = 3;
      }
    }
  }
  
  public static String a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, char[] paramArrayOfChar, boolean paramBoolean)
  {
    char[] arrayOfChar = a(paramArrayOfByte, paramInt1, paramInt2, paramArrayOfChar, 2147483647);
    for (int i = arrayOfChar.length;; i--) {
      if ((paramBoolean) || (i <= 0) || (arrayOfChar[(i - 1)] != '=')) {
        return new String(arrayOfChar, 0, i);
      }
    }
  }
  
  public static String a(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    return a(paramArrayOfByte, 0, paramArrayOfByte.length, b, paramBoolean);
  }
  
  public static byte[] a(String paramString)
    throws ap
  {
    char[] arrayOfChar = paramString.toCharArray();
    return a(arrayOfChar, 0, arrayOfChar.length);
  }
  
  public static byte[] a(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws ap
  {
    return a(paramArrayOfChar, paramInt1, paramInt2, c);
  }
  
  public static byte[] a(char[] paramArrayOfChar, int paramInt1, int paramInt2, byte[] paramArrayOfByte)
    throws ap
  {
    byte[] arrayOfByte1 = new byte[2 + paramInt2 * 3 / 4];
    int i = 0;
    char[] arrayOfChar = new char[4];
    int j = 0;
    int k = 0;
    int m = 0;
    int i1;
    int i3;
    if (k < paramInt2)
    {
      int n = paramArrayOfChar[(k + paramInt1)];
      i1 = n & 0x7F;
      int i2 = paramArrayOfByte[i1];
      if ((i1 == n) && (i2 < -5)) {
        throw new ap("Bad Base64 input character at " + k + ": " + paramArrayOfChar[(k + paramInt1)] + "(decimal)");
      }
      if (i2 < -1) {
        break label398;
      }
      if (i1 == 61) {
        if (j != 0) {
          i3 = i;
        }
      }
    }
    for (;;)
    {
      k++;
      i = i3;
      break;
      if (k < 2) {
        throw new ap("Invalid padding char found in position " + k);
      }
      j = 1;
      int i5 = (char)(0x7F & paramArrayOfChar[(paramInt1 + (paramInt2 - 1))]);
      if ((i5 != 61) && (i5 != 10)) {
        throw new ap("encoded value has invalid trailing char");
      }
      i3 = i;
      continue;
      if (j != 0) {
        throw new ap("Data found after trailing padding char at index " + k);
      }
      int i4 = m + 1;
      arrayOfChar[m] = i1;
      if (i4 == 4)
      {
        i3 = i + a(arrayOfChar, 0, arrayOfByte1, i, paramArrayOfByte);
        m = 0;
        continue;
        if (m != 0)
        {
          if (m == 1) {
            throw new ap("single trailing character at offset " + (paramInt2 - 1));
          }
          arrayOfChar[m] = '=';
          i += a(arrayOfChar, 0, arrayOfByte1, i, paramArrayOfByte);
        }
        byte[] arrayOfByte2 = new byte[i];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
        return arrayOfByte2;
      }
      else
      {
        m = i4;
        i3 = i;
        continue;
        label398:
        i3 = i;
      }
    }
  }
  
  public static char[] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3)
  {
    int i = 4 * ((paramInt2 + 2) / 3);
    char[] arrayOfChar = new char[i + i / paramInt3];
    int j = paramInt2 - 2;
    int k = 0;
    int m = 0;
    int n = 0;
    while (n < j)
    {
      int i1 = paramArrayOfByte[(n + paramInt1)] << 24 >>> 8 | paramArrayOfByte[(paramInt1 + (n + 1))] << 24 >>> 16 | paramArrayOfByte[(paramInt1 + (n + 2))] << 24 >>> 24;
      arrayOfChar[m] = paramArrayOfChar[(i1 >>> 18)];
      arrayOfChar[(m + 1)] = paramArrayOfChar[(0x3F & i1 >>> 12)];
      arrayOfChar[(m + 2)] = paramArrayOfChar[(0x3F & i1 >>> 6)];
      arrayOfChar[(m + 3)] = paramArrayOfChar[(i1 & 0x3F)];
      int i2 = k + 4;
      if (i2 == paramInt3)
      {
        arrayOfChar[(m + 4)] = '\n';
        m++;
        i2 = 0;
      }
      n += 3;
      m += 4;
      k = i2;
    }
    if (n < paramInt2)
    {
      a(paramArrayOfByte, n + paramInt1, paramInt2 - n, arrayOfChar, m, paramArrayOfChar);
      if (k + 4 == paramInt3)
      {
        arrayOfChar[(m + 4)] = '\n';
        m++;
      }
      (m + 4);
    }
    return arrayOfChar;
  }
  
  private static char[] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, char[] paramArrayOfChar1, int paramInt3, char[] paramArrayOfChar2)
  {
    int i = 0;
    int j;
    int k;
    label36:
    int n;
    if (paramInt2 > 0)
    {
      j = paramArrayOfByte[paramInt1] << 24 >>> 8;
      if (paramInt2 <= 1) {
        break label104;
      }
      k = paramArrayOfByte[(paramInt1 + 1)] << 24 >>> 16;
      int m = k | j;
      if (paramInt2 > 2) {
        i = paramArrayOfByte[(paramInt1 + 2)] << 24 >>> 24;
      }
      n = i | m;
      switch (paramInt2)
      {
      }
    }
    for (;;)
    {
      return paramArrayOfChar1;
      j = 0;
      break;
      label104:
      k = 0;
      break label36;
      paramArrayOfChar1[paramInt3] = paramArrayOfChar2[(n >>> 18)];
      paramArrayOfChar1[(paramInt3 + 1)] = paramArrayOfChar2[(0x3F & n >>> 12)];
      paramArrayOfChar1[(paramInt3 + 2)] = paramArrayOfChar2[(0x3F & n >>> 6)];
      paramArrayOfChar1[(paramInt3 + 3)] = paramArrayOfChar2[(n & 0x3F)];
      continue;
      paramArrayOfChar1[paramInt3] = paramArrayOfChar2[(n >>> 18)];
      paramArrayOfChar1[(paramInt3 + 1)] = paramArrayOfChar2[(0x3F & n >>> 12)];
      paramArrayOfChar1[(paramInt3 + 2)] = paramArrayOfChar2[(0x3F & n >>> 6)];
      paramArrayOfChar1[(paramInt3 + 3)] = '=';
      continue;
      paramArrayOfChar1[paramInt3] = paramArrayOfChar2[(n >>> 18)];
      paramArrayOfChar1[(paramInt3 + 1)] = paramArrayOfChar2[(0x3F & n >>> 12)];
      paramArrayOfChar1[(paramInt3 + 2)] = '=';
      paramArrayOfChar1[(paramInt3 + 3)] = '=';
    }
  }
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.aq
 * JD-Core Version:    0.7.0.1
 */
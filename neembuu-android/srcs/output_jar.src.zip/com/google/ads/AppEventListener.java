package com.google.ads;

public abstract interface AppEventListener
{
  public abstract void onAppEvent(Ad paramAd, String paramString1, String paramString2);
}


/* Location:           F:\neembuu\Research\android_apps\output_jar.jar
 * Qualified Name:     com.google.ads.AppEventListener
 * JD-Core Version:    0.7.0.1
 */